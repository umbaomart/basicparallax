# IllustratorImageLayoutToJSON
Exports layout position of placed images in Illustrator doc to JSON format.
